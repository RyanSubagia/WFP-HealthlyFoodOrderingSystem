<?php $__env->startSection('title'); ?>
Admin Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<?php
    $role = auth()->user()->role;
?>
<h1 class="card-title">Products</h1>
                <?php if($food): ?>
                <div class="container-admin-table">
                  <form action="<?php echo e(route('admin.product_admin')); ?>" method="GET">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="search" placeholder="Search product name..." value="<?php echo e(request('search')); ?>">
                    <button class="btn btn-primary" type="submit">Search</button>
                </div>
            </form>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Product Name</th>
                                    <th>Nutrition Facts</th>
                                    <th>Description</th>
                                    <th>Price</th>
                                    <?php if($role === 'admin'): ?>
                                    <th>Action</th>
                                    <?php endif; ?>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $food; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr id="tr_<?php echo e($item->id); ?>">
                                        <td>
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                            data-bs-target="#imageModal-<?php echo e($item->id); ?>">
                                            Show
                                            </button>
                                            <?php $__env->startPush('modals'); ?>
                                            <!-- Modal <?php echo e($item->id); ?> -->
                                            <div class="modal fade" id="imageModal-<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="imageModalLabel"
                                            aria-hidden="true">
                                            <div class="modal-dialog">
                                            <div class="modal-content">
                                            <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="imageModalLabel"><?php echo e($item->name); ?></h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">

                                            <img class="img-responsive" style="max-height:250px;"
                                            src="<?php echo e(asset('storage/menu_sushi/' . $item->image)); ?>" alt="<?php echo e($item->name); ?>"/>
                                            </div>
                                            <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            </div>
                                            </div>
                                            </div>
                                            </div>
                                            <?php $__env->stopPush(); ?>
                                        </td>
                                        <td>
                                            <?php echo e($item->name); ?>

                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-info btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#nutritionModal-<?php echo e($item->id); ?>">
                                            View Nutrition
                                            </button>
                                            <?php $__env->startPush('modals'); ?>
                                            <!-- Nutrition Modal <?php echo e($item->id); ?> -->
                                            <div class="modal fade" id="nutritionModal-<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="nutritionModalLabel"
                                            aria-hidden="true">
                                            <div class="modal-dialog">
                                            <div class="modal-content">
                                            <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="nutritionModalLabel">Nutrition Facts - <?php echo e($item->name); ?> </h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                            <div class="nutrition-facts">
                                                <p><strong>Nutrition Facts:</strong></p>
                                                <?php if($item->nutritionFact): ?>
                                                    <div class="nutrition-content">
                                                        <?php echo nl2br(e($item->nutritionFact->formatted_nutrition)); ?>

                                                    </div>
                                                <?php else: ?>
                                                    <p class="text-muted">Nutrition facts not found</p>
                                                <?php endif; ?>
                                            </div>
                                            </div>
                                            <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            </div>
                                            </div>
                                            </div>
                                            </div>
                                            <?php $__env->stopPush(); ?>
                                        </td>
                                        <td>
                                            <?php echo e($item->description); ?>

                                        </td>
                                        <td>
                                            <?php echo e($item->price); ?>

                                        </td>
                                        <?php if($role === 'admin'): ?>
                                        <td>
                                        <div>
                                        
                                        <a href="#modalEdit" class="btn btn-info" data-bs-toggle="modal" onclick="getEditForm(<?php echo e($item->id); ?>)">Edit</a>
                                        <?php $__env->startPush('script'); ?>
                                        <script>
                                        function getEditForm(id) {
                                          $.ajax({
                                          type: 'POST',
                                          url: '<?php echo e(route("admin.product.getEditForm")); ?>',
                                          data: {
                                            '_token': '<?php  echo csrf_token() ?>',
                                            'id': id
                                          },
                                        success: function (data) {
                                          $('#modalContent').html(data.msg)
                                        }
                                      });
                                    }
                                  </script>
                                <?php $__env->stopPush(); ?>
                                <div class="modal fade" id="modalEdit" tabindex="-1" role="basic" aria-hidden="true">
                                  <div class="modal-dialog modal-wide">
                                    <div class="modal-content">
                                    <div class="modal-body" id="modalContent">
                                    </div>
                                    </div>
                                  </div>
                                </div>

                                <?php $__env->startPush('script'); ?>
                                  <script>
                                    function saveDataUpdate(id) {
                                    $.ajax({
                                      type: 'POST',
                                      url: '<?php echo e(route("admin.product.saveDataUpdate")); ?>',
                                      data: {
                                        '_token': '<?php echo e(csrf_token()); ?>',
                                        'id': id,
                                        'name': $('#name').val(),
                                        'description': $('#description').val(),
                                        'price': $('#price').val(),
                                        'category_id': $('#category_id').val(),

                                        'calories': $('#calories').val(),
                                        'protein': $('#protein').val(),
                                        'fat': $('#fat').val(),
                                        'carbohydrates': $('#carbohydrates').val(),
                                        'fiber': $('#fiber').val(),
                                      },
                                      success: function (data) {
                                        if (data.status === "oke") {
                                          $('#modalEdit').modal('hide');
                                          alert("Berhasil diupdate!");
                                          location.reload();
                                        }
                                      },
                                      error: function(xhr) {
                                        alert("Gagal update");
                                        console.log(xhr.responseText);
                                      }
                                    });
                                  }
                                        </script>
                                        <?php $__env->stopPush(); ?>

                                       <a href="#" value="DeleteNoReload" class="btn btn-danger" 
                                          onclick="if(confirm('Are you sure to delete <?php echo e($item->id); ?> - <?php echo e($item->name); ?> ? ')) deleteDataRemove(<?php echo e($item->id); ?>)">
                                            <i class="fas fa-trash-alt me-1"></i> Hapus
                                        </a>
                                        <script>
                                          function deleteDataRemove(id) {
                                            $.ajax({
                                              type: 'POST',
                                              url: '<?php echo e(route("admin.product.destroy")); ?>',
                                              data: {
                                                _token: '<?php echo e(csrf_token()); ?>',
                                                id: id
                                              },
                                              success: function(data) {
                                                if (data.status === "oke") {
                                                  $('#tr_' + id).remove();
                                                  alert(data.msg);
                                                }
                                              },
                                              error: function(xhr) {
                                                console.error(xhr.responseText);
                                                alert("Gagal menghapus data.");
                                              }
                                            });
                                          }
                                          </script>
                                        </div>
                                        </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php if($role === 'admin'): ?>
                        <div>
                          <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#btnFormModal">+ New Menu</button>
                            <?php $__env->startPush('modals'); ?>
                          <div class="modal fade" id="btnFormModal" tabindex="-1" role="basic" aria-hidden="true">
                            <div class="modal-dialog">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h4 class="modal-title">Add New Menu</h4>
                                </div>
                                <div class="modal-body">
                                  <form method="POST" action="<?php echo e(route('admin.product.store')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="name">Name</label>
                                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter Meals Name">
                                        <br>

                                        <label for="calories">Calories</label>
                                        <input type="text" class="form-control" id="calories" name="calories">
                                        <br>

                                        <label for="protein">Protein</label>
                                        <input type="text" class="form-control" id="protein" name="protein">
                                        <br>

                                        <label for="fat">Fat</label>
                                        <input type="text" class="form-control" id="fat" name="fat">
                                        <br>

                                        <label for="carbohydrates">Carbohydrates</label>
                                        <input type="text" class="form-control" id="carbohydrates" name="carbohydrates">
                                        <br>

                                        <label for="fiber">Fiber</label>
                                        <input type="text" class="form-control" id="fiber" name="fiber">
                                        <br>

                                        <label for="description">Description</label>
                                        <textarea class="form-control" id="description" name="description" placeholder="Enter Description"></textarea>
                                        <br>

                                        <label for="price">Price</label>
                                        <input type="number" class="form-control" id="price" name="price" placeholder="Enter Price">
                                        <br>

                                        <label for="category_id">Category</label>
                                        <select name="category_id" id="category_id" class="form-control">
                                            <option value="">-- Select Category --</option>
                                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <br>

                                        <label for="image">Image</label>
                                        <input type="file" class="form-control" id="image" name="image">
                                    </div>

                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                        <button type="button" class="btn btn-default" data-bs-dismiss="modal">Cancel</button>
                                    </div>
                                </form>
                              </div>
                            </div>
                          </div>
                            <?php $__env->stopPush(); ?>
                        </div>
                        <?php endif; ?>
                        <div class="d-flex justify-content-center mt-4">
                            <?php echo e($food->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
                <?php else: ?>
                    <div class="alert alert-info">Belum ada data customer</div>
                <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WFP-HealthlyFoodOrderingSystem\FoodOrderingSystem\resources\views/admin/products/product.blade.php ENDPATH**/ ?>