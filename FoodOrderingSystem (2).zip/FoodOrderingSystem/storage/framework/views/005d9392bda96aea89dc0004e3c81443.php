<?php $__env->startSection('title'); ?>
Admin Transaction
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<h1 class="card-title">Order</h1>
                <?php if($transaction): ?>
                <div class="container-admin-table">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>id</th>
                            <th>Total (Rp.)</th>
                            <th>Order Date</th>
                            <th>Table Number</th>
                            <th>Method</th>
                            <th>Status</th>
                            <th>Details</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->total); ?></td>
                            <td><?php echo e($item->tgl_Pemesanan); ?></td>
                            <td><?php echo e($item->no_meja); ?></td>
                            <td><?php echo e($item->metode_Pemesanan); ?></td>
                            <td>
                                <?php
                                    // status berikutnya
                                    $next = \App\Models\Transaction::NEXT_STATUS[$item->status] ?? null;
                                ?>

                                
                                <?php if($next): ?>
                                    <form action="<?php echo e(route('admin.orders.updateStatus', $item->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>

                                        <select name="status"
                                                class="form-select form-select-sm"
                                                onchange="this.form.submit()">
                                            
                                            <option selected disabled><?php echo e(ucfirst($item->status)); ?></option>
                                            
                                            <option value="<?php echo e($next); ?>"><?php echo e(ucfirst($next)); ?></option>
                                        </select>
                                    </form>
                                <?php else: ?>
                                    
                                    <?php
                                        $status = strtolower($item->status);
                                        $badgeClass = match ($status) {
                                            'pending'    => 'bg-warning text-dark',
                                            'processing' => 'bg-primary',
                                            'ready'      => 'bg-info text-dark',
                                            'completed'  => 'bg-success',
                                            'cancelled'  => 'bg-danger', // merah
                                            default      => 'bg-secondary',
                                        };
                                    ?>

                                    <span class="badge <?php echo e($badgeClass); ?>">
                                        <?php echo e(ucfirst($status)); ?>

                                    </span>

                                <?php endif; ?>
                            </td>


                            <td>
                                <a href="<?php echo e(route('admin.orders.details', $item->id)); ?>"
                                    class="btn btn-sm btn-primary">
                                    Details
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                        </table>
                        <div class="d-flex justify-content-center mt-4">
                            <?php echo e($transaction->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
                <?php else: ?>
                    <div class="alert alert-info">Belum ada data customer</div>
                <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WFP-HealthlyFoodOrderingSystem\FoodOrderingSystem\resources\views/admin/order.blade.php ENDPATH**/ ?>