<?php $__env->startSection('title'); ?>
Admin Kategori
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<?php
    $role = auth()->user()->role;
?>
<h1 class="card-title">Categories</h1>
                <?php if($category): ?>
                <div class="container-admin-table">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>id</th>
                                    <th>Food Type</th>
                                    <th>Quantity</th>
                                    <th>Food List</th>
                                    <?php if($role === 'admin'): ?>
                                    <th>Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr id="tr_<?php echo e($item->id); ?>">
                                        <td>
                                            <?php echo e($item->id); ?>

                                        </td>
                                        <td id="td_name_<?php echo e($item->id); ?>"><?php echo e($item->name); ?></td>
                                        <td><?php echo e(count($item->foods)); ?></td>
                                        <td>
                                          <button type="button" class="btn btn-info" data-bs-toggle="modal" 
                                              data-bs-target="#detailModal" onclick="showDetail(<?php echo e($item->id); ?>)" >
                                              Details
                                          </button>

                                          <?php $__env->startPush('modals'); ?>
                                         
                                          <div class="modal fade" id="detailModal" tabindex="-1" aria-labelledby="detailModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                              <div class="modal-content">
                                                <div class="modal-header">
                                                  <h1 class="modal-title fs-5" id="detail-title">List of Foods</h1>
                                                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body" id="detail-body">
                                                  
                                                </div>
                                                <div class="modal-footer">
                                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                          <?php $__env->stopPush(); ?>
                                          <?php $__env->startPush("script"); ?>
                                          <script>
                                          function showDetail(id) {
                                            $.ajax({
                                              type: 'POST',
                                              url: '<?php echo e(route("admin.category.showListFoods")); ?>',
                                              data: { 
                                                      '_token': '<?php echo csrf_token(); ?>',
                                                      'idcat': id,
                                                    },
                                              success: function(data) {
                                                $('#detail-title').html(data.title);
                                                $('#detail-body').html(data.body);
                                              }
                                            });
                                          }
                                          </script>
                                          <?php $__env->stopPush(); ?>
                                        </ul>
                                      </td>
                                      <?php if($role === 'admin'): ?>
                                      <td>
                                        <div>
                                        <a href="#modalEdit" class="btn btn-info" data-bs-toggle="modal" onclick="getEditForm(<?php echo e($item->id); ?>)">Edit</a>
                                        <?php $__env->startPush('script'); ?>
                                        <script>
                                        function getEditForm(id) {
                                          $.ajax({
                                          type: 'POST',
                                          url: '<?php echo e(route("admin.category.getEditForm")); ?>',
                                          data: {
                                            '_token': '<?php  echo csrf_token() ?>',
                                            'id': id
                                          },
                                        success: function (data) {
                                          $('#modalContent').html(data.msg)
                                        }
                                      });
                                    }
                                  </script>
                                <?php $__env->stopPush(); ?>
                                <div class="modal fade" id="modalEdit" tabindex="-1" role="basic" aria-hidden="true">
                                  <div class="modal-dialog modal-wide">
                                    <div class="modal-content">
                                    <div class="modal-body" id="modalContent">
                                    </div>
                                    </div>
                                  </div>
                                </div>

                                <?php $__env->startPush('script'); ?>
                                  <script>
                                    function saveDataUpdate(id) {
                                      var name = $('#name').val();
                                      console.log(name); 
                                      $.ajax({
                                        type: 'POST',
                                        url: '<?php echo e(route("admin.category.saveDataUpdate")); ?>',
                                        data: {
                                        '_token': '<?php  echo csrf_token(); ?>',
                                        'id': id,
                                          'name': name,
                                          },
                                          success: function (data) {
                                          if (data.status == "oke") {
                                          $('#td_name_' + id).html(name);
                                            $('#modalEdit').modal('hide');
                                            alert("Berhasil diupdate!");
                                            location.reload();
                                          }
                                          },
                                          error: function(xhr) {
                                          alert("Gagal update");
                                          console.log(xhr.responseText);
                                          }
                                        });
                                        }
                                        </script>
                                        <?php $__env->stopPush(); ?>

                                       <a href="#" value="DeleteNoReload" class="btn btn-danger" 
                                          onclick="if(confirm('Are you sure to delete <?php echo e($item->id); ?> - <?php echo e($item->name); ?> ? ')) deleteDataRemove(<?php echo e($item->id); ?>)">
                                            <i class="fas fa-trash-alt me-1"></i> Hapus
                                        </a>
                                        <script>
                                          function deleteDataRemove(id) {
                                            $.ajax({
                                              type: 'POST',
                                              url: '<?php echo e(route("admin.category.destroy")); ?>',
                                              data: {
                                                _token: '<?php echo e(csrf_token()); ?>',
                                                id: id
                                              },
                                              success: function(data) {
                                                if (data.status === "oke") {
                                                  $('#tr_' + id).remove();
                                                  alert(data.msg);
                                                } else if (data.status === "error") {
                                                  alert("Error: " + data.msg);
                                                }
                                              },
                                              error: function(xhr) {
                                                try {
                                                  var response = JSON.parse(xhr.responseText);
                                                  if (response.status === "error") {
                                                    alert("Error: " + response.msg);
                                                  } else {
                                                    alert("An error occurred while deleting the category.");
                                                  }
                                                } catch (e) {
                                                  console.error(xhr.responseText);
                                                  alert("An error occurred while deleting the category.");
                                                }
                                              }
                                            });
                                          }
                                          </script>
                                        </div>
                                      </td>
                                      <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php if($role === 'admin'): ?>
                        <div>
                          <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#btnFormModal">+ New Category</button>
                            <?php $__env->startPush('modals'); ?>
                          <div class="modal fade" id="btnFormModal" tabindex="-1" role="basic" aria-hidden="true">
                            <div class="modal-dialog">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h4 class="modal-title">Add New Category</h4>
                                </div>
                                <div class="modal-body">
                                  <form method="POST" action="<?php echo e(route('admin.category.store')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                      <label for="name">Name</label>
                                      <input type="text" class="form-control" id="name" name="name" aria-describedby="name"
                                        placeholder="Enter Category Name">
                                      <small id="name" class="form-text text-muted">Please write down Category Name here.</small>
                                    </div>
                                 </div>
                                  <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                    <button type="button" class="btn btn-default" data-bs-dismiss="modal">Cancel</button>
                                  </div>
                                </form>
                              </div>
                            </div>
                          </div>
                            <?php $__env->stopPush(); ?>
                        </div>
                        <?php endif; ?>
                        <div class="d-flex justify-content-center mt-4">
                            <?php echo e($category->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
                <?php else: ?>
                    <div class="alert alert-info">Belum ada data customer</div>
                <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WFP-HealthlyFoodOrderingSystem\FoodOrderingSystem\resources\views/admin/categories/category.blade.php ENDPATH**/ ?>