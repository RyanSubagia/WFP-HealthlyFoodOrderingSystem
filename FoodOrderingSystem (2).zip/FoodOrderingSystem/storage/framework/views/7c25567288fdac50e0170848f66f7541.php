<?php $__env->startSection('title'); ?>
Admin Employee
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<h1 class="card-title">Employee</h1>
                <?php if($employee->count()): ?>
                <div class="container-admin-table">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Telephone Number</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr id="tr_<?php echo e($e->id); ?>">
                                        <td>
                                            <?php echo e($e->id); ?>

                                        </td>
                                        <td>
                                            <?php echo e($e->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($e->email); ?>

                                        </td>
                                        <td>
                                            <?php echo e($e->no_telp); ?>

                                        </td>

                                         <td>
                                        <div>
                                        
                                        <a href="#modalEdit" class="btn btn-info" data-bs-toggle="modal" onclick="getEditForm(<?php echo e($e->id); ?>)">Edit</a>
                                        <?php $__env->startPush('script'); ?>
                                        <script>
                                        function getEditForm(id) {
                                        $.ajax({
                                            type: 'POST',
                                            url: '<?php echo e(route("admin.employee.getEditForm")); ?>',
                                            data: {
                                            _token: '<?php echo e(csrf_token()); ?>',
                                            id: id
                                            },
                                            success: function (data) {
                                            if (data.status === 'ok') {
                                                $('#modalContent').html(data.msg);
                                            } else {
                                                alert(data.msg);
                                            }
                                            }
                                        });
                                        }
                                  </script>
                                <?php $__env->stopPush(); ?>
                                <div class="modal fade" id="modalEdit" tabindex="-1" role="basic" aria-hidden="true">
                                  <div class="modal-dialog modal-wide">
                                    <div class="modal-content">
                                    <div class="modal-body" id="modalContent">
                                    
                                    </div>
                                    </div>
                                  </div>
                                </div>

                                <?php $__env->startPush('script'); ?>
                                  <script>
                                    function saveEmployeeUpdate(id) {
                                    $.ajax({
                                        type: 'POST',
                                        url: '<?php echo e(route("admin.employee.saveDataUpdate")); ?>',
                                        data: {
                                        _token: '<?php echo e(csrf_token()); ?>',
                                        id: id,
                                        name: $('#name').val(),
                                        email: $('#email').val(),
                                        no_telp: $('#no_telp').val(),
                                        password: $('#password').val()
                                        },
                                        success: function (data) {
                                        if (data.status === 'oke') {
                                            $('#modalEdit').modal('hide');
                                            alert(data.msg);
                                            location.reload();
                                        } else {
                                            alert(data.msg);
                                        }
                                        },
                                        error: function (xhr) {
                                        console.error(xhr.responseText);
                                        alert("Gagal menyimpan data.");
                                        }
                                    });
                                    }
                                        </script>
                                        <?php $__env->stopPush(); ?>

                                       <a href="#" value="DeleteNoReload" class="btn btn-danger" 
                                          onclick="if(confirm('Are you sure to delete <?php echo e($e->id); ?> - <?php echo e($e->name); ?> ? ')) deleteDataRemove(<?php echo e($e->id); ?>)">
                                            <i class="fas fa-trash-alt me-1"></i> Hapus
                                        </a>
                                        <script>
                                          function deleteDataRemove(id) {
                                            $.ajax({
                                              type: 'POST',
                                              url: '<?php echo e(route("admin.employee.destroy")); ?>',
                                              data: {
                                                _token: '<?php echo e(csrf_token()); ?>',
                                                id: id
                                              },
                                              success: function(data) {
                                                if (data.status === "oke") {
                                                  $('#tr_' + id).remove();
                                                  alert(data.msg);
                                                }
                                              },
                                              error: function(xhr) {
                                                console.error(xhr.responseText);
                                                alert("Gagal menghapus data.");
                                              }
                                            });
                                          }
                                          </script>
                                        </div>
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="d-flex justify-content-center mt-4">
                            <?php echo e($employee->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
                <?php else: ?>
                    <div class="alert alert-info">Belum ada data admin</div>
                <?php endif; ?>
                 <div>
                          <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#btnFormModal">+ New Employee</button>
                          
                            <?php $__env->startPush('modals'); ?>
                          <div class="modal fade" id="btnFormModal" tabindex="-1" role="basic" aria-hidden="true">
                            <div class="modal-dialog">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h4 class="modal-title">Add New Employee</h4>
                                </div>
                                <div class="modal-body">
                                  <form method="POST" action="<?php echo e(route('admin.addEmployee.store')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="name">Name</label>
                                        <input type="text" class="form-control" id="name" name="name" aria-describedby="name"
                                            placeholder="Enter Employee Name">
                                        <br>
                                        <label for="email">Email</label>
                                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email">
                                        <br>
                                        <label for="password">Password</label>
                                        <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password">
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                        <button type="button" class="btn btn-default" data-bs-dismiss="modal">Cancel</button>
                                    </div>
                                </form>
                              </div>
                            </div>
                          </div>
                            <?php $__env->stopPush(); ?>

                        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WFP-HealthlyFoodOrderingSystem\FoodOrderingSystem\resources\views/admin/employee/employee.blade.php ENDPATH**/ ?>