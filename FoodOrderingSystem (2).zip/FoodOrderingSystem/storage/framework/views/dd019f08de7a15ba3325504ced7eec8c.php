<nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="/">
            <img src="<?php echo e(asset('img/logo/logo_Navigasi.png')); ?>" alt="Logo" style="height: 35px;">
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav align-items-center">
                <li class="nav-item mx-3">
                    <a href="<?php echo e(url('/')); ?>"
                        class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">Home</a>
                </li>
                <li class="nav-item mx-3">
                    <a href="<?php echo e(route('about')); ?>"
                        class="nav-link <?php echo e(request()->routeIs('about') ? 'active' : ''); ?>">About Us</a>
                </li>
                <li class="nav-item mx-3">
                    <a href="<?php echo e(route('menu.index')); ?>"
                        class="nav-link <?php echo e(request()->routeIs('menu') ? 'active' : ''); ?> <?php echo $__env->yieldContent('menu'); ?>">Menu</a>
                </li>

                <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item mx-3">
                        <a class="nav-link <?php echo e(request()->routeIs('customer.cart.index') ? 'active' : ''); ?>"
                            href="<?php echo e(route('customer.cart.index')); ?>"> Cart
                        </a>
                    </li>
                    <li class="nav-item mx-3">
                        <a class="nav-link <?php echo e(request()->routeIs('customer.cart.history') ? 'active' : ''); ?>"
                            href="<?php echo e(route('customer.cart.history')); ?>">History</a>
                    </li>
                    <li class="nav-item mx-3 d-flex align-items-center">
                        Point &nbsp; <span class="badge bg-success ms-1"><?php echo e(auth()->user()->poin); ?></span>
                        </span>
                    </li>
                <?php endif; ?>
            </ul>

            <!-- Login button or user dropdown -->
            <?php if(auth()->check()): ?>
                <div class="dropdown ms-4">
                    <button class="btn dropdown-toggle user-greeting" type="button" id="userDropdown"
                        data-bs-toggle="dropdown" aria-expanded="false"
                        style="background: none; border: none; color: #333; font-weight: 500;">
                        Hello, <?php echo e(auth()->user()->name); ?>

                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <li>
                            <form action="<?php echo e(route('logout')); ?>" method="POST" style="margin: 0;">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="dropdown-item"
                                    style="color: #dc3545; border: none; background: none; width: 100%; text-align: left;">
                                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                                </button>
                            </form>
                        </li>
                    </ul>
                </div>
            <?php else: ?>
                <a href="/login" class="btn login-btn ms-4 rounded-pill px-4 py-2"
                    style="background-color: #F58232; color: white;">Login</a>
            <?php endif; ?>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\WFP-HealthlyFoodOrderingSystem\FoodOrderingSystem\resources\views/partials/navigasi.blade.php ENDPATH**/ ?>