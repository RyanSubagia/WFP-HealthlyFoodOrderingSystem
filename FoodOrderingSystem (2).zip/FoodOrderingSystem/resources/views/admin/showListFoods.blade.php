<ul>
    @foreach ($data as $f)
      <li>{{$f->name}}</li>
    @endforeach
</ul>
    