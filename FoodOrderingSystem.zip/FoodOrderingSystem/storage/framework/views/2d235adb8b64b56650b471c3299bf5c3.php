<?php $__env->startSection('title', 'Order #'.$transaction->id.' – Detail'); ?>

<?php $__env->startSection('container'); ?>
    <h1 class="card-title mb-4">Detail Order #<?php echo e($transaction->id); ?></h1>

    
    <div class="mb-3">
        <strong>Tanggal:</strong> <?php echo e($transaction->tgl_Pemesanan); ?><br>
        <strong>Total (Rp):</strong> <?php echo e(number_format($transaction->total, 0, ',', '.')); ?><br>
        <strong>Status:</strong> <?php echo e(ucfirst($transaction->status)); ?>

    </div>

    
    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>id</th>
                    <th>Food</th>
                    <th>Size</th>
                    <th>Note</th>
                    <th>Qty</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($row->id); ?></td>
                    <td><?php echo e($row->food->name ?? '—'); ?></td>
                    <td><?php echo e($row->size); ?></td>
                    <td><?php echo e($row->note ?: '—'); ?></td>
                    <td><?php echo e($row->quantity); ?></td>
                    <td><?php echo e(number_format($row->price, 0, ',', '.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary mt-3">← Back</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WFP-HealthlyFoodOrderingSystem\FoodOrderingSystem\resources\views/admin/order_detail.blade.php ENDPATH**/ ?>