<?php $__env->startSection('title'); ?>
Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
    <h1>Dashboard </h1>
    <ul class="show">
        <li class="item">Most products by category: <strong><?php echo e($mostFood->name ?? '-'); ?></strong></li>
        <li class="item">Most active member: <strong><?php echo e($mostActiveMember->name ?? '-'); ?></strong></li>
        <li class="item">Member with the most purchases: <strong><?php echo e($mostPurchasingMember->name ?? '-'); ?></strong></li>
        <li class="item">Total Revenue: <strong>Rp<?php echo e(number_format($totalRevenue, 0, ',', '.')); ?></strong></li>
        <li class="item">Best selling products: <strong><?php echo e($topProduct->name ?? '-'); ?></strong></li>
        <li class="item">Products that need to be endorsed: <strong><?php echo e($endorseProduct->name ?? '-'); ?></strong></li>
    </ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WFP-HealthlyFoodOrderingSystem\FoodOrderingSystem\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>