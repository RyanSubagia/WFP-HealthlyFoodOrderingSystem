<?php $__env->startSection('title', 'My Cart'); ?>

<?php $__env->startSection('container'); ?>
    <section class="about-hero position-relative">
        <div class="container-fluid p-0">
            <div class="hero-overlay d-flex align-items-center justify-content-center text-center"
                style="background-image: url('<?php echo e(asset('img/illustration/background_about.png')); ?>'); background-size: cover; background-position: center; height: 400px;">
                <div
                    style="background-color: rgba(0,0,0,0.5); position: absolute; top: 0; left: 0; width: 100%; height: 100%;">
                </div>
                <div class="position-relative" style="z-index: 2;">
                    <h1 class="display-4 fw-bold text-white mb-2">My Cart</h1>
                </div>
            </div>
        </div>
    </section>

    <section class="py-5 bg-light">
        <div class="container">
            <?php if(session('success')): ?>
                <div class="alert alert-success text-center"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if($carts->isEmpty()): ?>
                <div class="alert alert-info text-center">Keranjang kamu masih kosong.</div>
            <?php else: ?>
                <div class="table-responsive mb-4">
                    <table class="table table-bordered align-middle bg-white">
                        <thead class="table-light">
                            <tr>
                                <th>Gambar</th>
                                <th>Nama</th>
                                <th>Ukuran</th>
                                <th>Catatan & Condiments</th>
                                <th>Harga</th>
                                <th>Jumlah</th>
                                <th>Total</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $grandTotal = 0;
                                $condiments = [
                                    'shoyu',
                                    'wasabi',
                                    'gari',
                                    'togarashi',
                                    'ponzu',
                                    'mayones',
                                    'teriyaki',
                                    'chili_Oil',
                                ];
                            ?>
                            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $price = $item->food->price;
                                    $sizeCharge = $item->size === 'L' ? 5000 : 0;

                                    $condimentPrice = 0;
                                    foreach ($condiments as $condiment) {
                                        if ($item->$condiment) {
                                            $condimentPrice += 2000;
                                        }
                                    }

                                    $finalPrice = $price + $sizeCharge + $condimentPrice;
                                    $total = $finalPrice * $item->quantity;
                                    $grandTotal += $total;
                                ?>
                                <tr>
                                    <td><img src="<?php echo e(asset('storage/menu_sushi/' . $item->food->image)); ?>" class="img-fluid"
                                            style="max-height: 80px;"></td>
                                    <td><?php echo e($item->food->name); ?></td>
                                    <td><?php echo e($item->size); ?></td>
                                    <td>
                                        <?php echo e($item->note ?? '-'); ?><br>
                                        <?php $__currentLoopData = $condiments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item->$c): ?>
                                                <span
                                                    class="badge bg-secondary mt-1"><?php echo e(ucfirst(str_replace('_', ' ', $c))); ?></span>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>Rp <?php echo e(number_format($finalPrice, 0, ',', '.')); ?></td>
                                    <td><?php echo e($item->quantity); ?></td>
                                    <td>Rp <?php echo e(number_format($total, 0, ',', '.')); ?></td>
                                    <td>
                                        <button class="btn btn-danger"
                                            onclick="deleteCartItem(<?php echo e($item->id); ?>)">✕</button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="6" class="text-end fw-bold">Total:</td>
                                <td class="fw-bold">Rp <?php echo e(number_format($grandTotal, 0, ',', '.')); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <form action="<?php echo e(route('customer.cart.checkout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label for="type" class="form-label"><strong>Tipe Pemesanan</strong></label>
                        <select name="type" id="type" class="form-select" onchange="toggleTableInput(this.value)"
                            required>
                            <option value="Take-Away">Take-Away</option>
                            <option value="Dine-In" selected>Dine-In</option>
                        </select>
                        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3" id="table-number-group">
                        <label for="table_number" class="form-label">Nomor Meja</label>
                        <input type="text" name="table_number" id="table_number" class="form-control"
                            placeholder="Contoh: A12">
                        <?php $__errorArgs = ['table_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="payments_id" class="form-label"><strong>Metode Pembayaran</strong></label>
                        <select name="payments_id" id="payments_id" class="form-select" required>
                            <option value="">-- Pilih Metode Pembayaran --</option>
                            <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($payment->id); ?>"><?php echo e($payment->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['payments_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" name="use_points" id="use_points">
                        <label class="form-check-label" for="use_points">
                            Use Poin? You had <?php echo e(auth()->user()->poin); ?> poin,  (MAX discount 50%)
                        </label>
                    </div>


                    <div class="text-end">
                        <button type="submit" class="btn btn-success px-4">Checkout</button>
                    </div>
                </form>

                <script>
                    function toggleTableInput(value) {
                        const group = document.getElementById('table-number-group');
                        const input = document.getElementById('table_number');

                        if (value === 'Dine-In') {
                            group.style.display = 'block';
                            input.setAttribute('required', 'required');
                        } else {
                            group.style.display = 'none';
                            input.removeAttribute('required');
                            input.value = '';
                        }
                    }

                    document.addEventListener("DOMContentLoaded", function() {
                        toggleTableInput("Dine-In");
                    });

                    function deleteCartItem(id) {
                        if (confirm("Yakin ingin menghapus item ini?")) {
                            fetch("<?php echo e(route('customer.cart.destroy')); ?>", {
                                    method: "POST",
                                    headers: {
                                        'Content-Type': 'application/json',
                                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                                    },
                                    body: JSON.stringify({
                                        id
                                    })
                                }).then(res => res.json())
                                .then(data => {
                                    if (data.status === "oke") location.reload();
                                    else alert("Gagal menghapus");
                                });
                        }
                    }
                </script>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WFP-HealthlyFoodOrderingSystem\FoodOrderingSystem\resources\views/customer/cart.blade.php ENDPATH**/ ?>