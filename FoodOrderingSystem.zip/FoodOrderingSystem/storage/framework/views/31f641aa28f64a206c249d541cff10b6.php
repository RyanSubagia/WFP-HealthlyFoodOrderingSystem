<div class="col-lg-4 col-md-6 col-sm-12">
    <div class="card menu-card h-100" data-bs-toggle="modal" data-bs-target="#modalFood<?php echo e($f->id); ?>" style="cursor: pointer;">
        <div class="menu-card-image">
            <img src="<?php echo e(asset('storage/menu_sushi/' . $f->image)); ?>" alt="<?php echo e($f->name); ?>"
                 onerror="this.onerror=null; this.src='<?php echo e(asset('storage/menu_sushi/default.jpg')); ?>';" />
        </div>
        
        <div class="card-body d-flex flex-column">
            <div class="d-flex justify-content-between align-items-start mb-2">
                <h5 class="card-title fw-bold mb-0"><?php echo e($f->name); ?></h5>
                <span class="category-badge"><?php echo e($f->category->name); ?></span>
            </div>
            
            <p class="card-text text-muted flex-grow-1 mb-3">
                <?php echo e(Str::limit($f->description ?? 'Delicious Japanese cuisine prepared with fresh ingredients.', 80)); ?>

            </p>
            
            <div class="d-flex justify-content-between align-items-center">
                <span class="price-badge">
                    Rp <?php echo e(number_format($f->price, 0, ',', '.')); ?>

                </span>
                <button class="btn btn-outline-danger btn-sm">
                    <i class="fas fa-plus me-1"></i>Add to Cart
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Enhanced Modal -->
<div class="modal fade" id="modalFood<?php echo e($f->id); ?>" tabindex="-1" aria-labelledby="modalLabel<?php echo e($f->id); ?>" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <form action="<?php echo e(route('customer.cart.add')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="food_id" value="<?php echo e($f->id); ?>">

            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title fw-bold" id="modalLabel<?php echo e($f->id); ?>"><?php echo e($f->name); ?></h5>
                        <small class="text-white-50"><?php echo e($f->category->name); ?></small>
                    </div>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-5">
                            <div class="text-center mb-4">
                                <img src="<?php echo e(asset('storage/menu_sushi/' . $f->image)); ?>" alt="<?php echo e($f->name); ?>"
                                     onerror="this.onerror=null; this.src='<?php echo e(asset('storage/menu_sushi/default.jpg')); ?>';"
                                     class="img-fluid rounded-3" style="max-height: 250px; object-fit: contain;" />
                            </div>
                        </div>
                        
                        <div class="col-md-7">
                            <div class="mb-4">
                                <h6 class="fw-bold text-danger mb-2">
                                    <i class="fas fa-info-circle me-2"></i>Description
                                </h6>
                                <p class="text-muted"><?php echo e($f->description ?? 'Delicious Japanese cuisine prepared with fresh ingredients.'); ?></p>
                            </div>

                            <div class="nutrition-facts mb-4">
                                <h6 class="fw-bold text-danger mb-2">
                                    <i class="fas fa-chart-pie me-2"></i>Nutrition Facts
                                </h6>
                                <?php if($f->nutritionFact): ?>
                                    <div class="nutrition-content small">
                                        <?php echo nl2br(e($f->nutritionFact->formatted_nutrition)); ?>

                                    </div>
                                <?php else: ?>
                                    <p class="text-muted small">Nutrition information not available</p>
                                <?php endif; ?>
                            </div>

                            <div class="mb-4">
                                <h6 class="fw-bold text-success mb-2">
                                    <i class="fas fa-tag me-2"></i>Price
                                </h6>
                                <span class="h4 text-success fw-bold">Rp <?php echo e(number_format($f->price, 0, ',', '.')); ?></span>
                            </div>
                        </div>
                    </div>

                    <hr class="my-4">

                    <!-- Customization Options -->
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-4">
                                <label for="size<?php echo e($f->id); ?>" class="form-label fw-bold">
                                    <i class="fas fa-expand-arrows-alt me-2 text-primary"></i>Size
                                </label>
                                <select class="form-select form-select-lg" id="size<?php echo e($f->id); ?>" name="size" required>
                                    <option value="S">Small (S)</option>
                                    <option value="M" selected>Medium (M)</option>
                                    <option value="L">Large (L) <span class="text-success">+Rp 5,000</span></option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="mb-4">
                                <label for="note<?php echo e($f->id); ?>" class="form-label fw-bold">
                                    <i class="fas fa-sticky-note me-2 text-warning"></i>Special Notes
                                </label>
                                <textarea class="form-control" id="note<?php echo e($f->id); ?>" name="note" rows="3"
                                          placeholder="Any special requests? (e.g., no wasabi, extra ginger)"></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- Condiments Section -->
                    <div class="condiment-section">
                        <h6 class="fw-bold text-danger mb-3">
                            <i class="fas fa-pepper-hot me-2"></i>Condiments 
                            <span class="badge bg-danger">+Rp 2,000 each</span>
                        </h6>
                        
                        <div class="row">
                            <?php 
                                $condiments = [
                                    ['value' => 'Shoyu', 'label' => 'Shoyu', 'icon' => '🍱'],
                                    ['value' => 'Wasabi', 'label' => 'Wasabi', 'icon' => '🟢'],
                                    ['value' => 'Gari', 'label' => 'Gari (Pickled Ginger)', 'icon' => '🫚'],
                                    ['value' => 'Togarashi', 'label' => 'Togarashi', 'icon' => '🌶️'],
                                    ['value' => 'Ponzu', 'label' => 'Ponzu', 'icon' => '🍋'],
                                    ['value' => 'Mayones', 'label' => 'Japanese Mayo', 'icon' => '🥄'],
                                    ['value' => 'Teriyaki', 'label' => 'Teriyaki', 'icon' => '🍯'],
                                    ['value' => 'Chili Oil', 'label' => 'Chili Oil', 'icon' => '🌶️'],
                                ];
                            ?>
                            
                            <?php $__currentLoopData = $condiments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $condiment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 col-12 mb-2">
                                    <div class="form-check form-check-lg">
                                        <input class="form-check-input" type="checkbox" name="condiments[]" 
                                               value="<?php echo e($condiment['value']); ?>" 
                                               id="condiment-<?php echo e(Str::slug($condiment['value'])); ?>-<?php echo e($f->id); ?>">
                                        <label class="form-check-label fw-500" for="condiment-<?php echo e(Str::slug($condiment['value'])); ?>-<?php echo e($f->id); ?>">
                                            <span class="me-2"><?php echo e($condiment['icon']); ?></span>
                                            <?php echo e($condiment['label']); ?>

                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-2"></i>Cancel
                    </button>
                    <button type="submit" class="btn btn-danger btn-lg px-4">
                        <i class="fas fa-cart-plus me-2"></i>Add to Cart
                    </button>
                </div>
            </div>
        </form>
    </div>
</div><?php /**PATH C:\xampp\htdocs\WFP-HealthlyFoodOrderingSystem\FoodOrderingSystem\resources\views/partials/menu-card.blade.php ENDPATH**/ ?>