<?php $__env->startSection('title'); ?>
    Menu
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
    <h1>Menu</h1>
    <div class="container-fluid">
        <h2 class="mb-4">Choose Your Menu</h2>
        <div class="row">
            <?php $__currentLoopData = $food; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <!-- Card: Click to open modal -->
                    <div class="card h-100" data-bs-toggle="modal" data-bs-target="#modalFood<?php echo e($f->id); ?>"
                        style="cursor: pointer;">
                        <img class="img-fluid mx-auto d-block" style="max-height: 200px; object-fit: contain;"
                            src="<?php echo e(asset('storage/menu_sushi/' . $f->image)); ?>" alt="<?php echo e($f->name); ?>"
                            onerror="this.onerror=null; this.src='<?php echo e(asset('storage/menu_sushi/default.jpg')); ?>';" />

                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($f->name); ?></h5>
                            <p class="card-text">
                                <strong>Category:</strong> <?php echo e($f->category->name); ?><br>
                                <strong>Price:</strong> Rp. <?php echo e(number_format($f->price, 0, ',', '.')); ?>,-
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Modal -->
                <div class="modal fade" id="modalFood<?php echo e($f->id); ?>" tabindex="-1"
                    aria-labelledby="modalLabel<?php echo e($f->id); ?>" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <form action="<?php echo e(route('customer.cart.add')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="food_id" value="<?php echo e($f->id); ?>">

                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalLabel<?php echo e($f->id); ?>"><?php echo e($f->name); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>

                                <div class="modal-body">
                                    <img src="<?php echo e(asset('storage/menu_sushi/' . $f->image)); ?>" alt="<?php echo e($f->name); ?>"
                                    onerror="this.onerror=null; this.src='<?php echo e(asset('storage/menu_sushi/default.jpg')); ?>';"
                                    style="max-height: 200px; object-fit: contain;"/>

                                    <p><strong>Description:</strong> <?php echo e($f->description); ?></p>
                                    <div class="nutrition-facts">
                                    <p><strong>Nutrition Facts:</strong>
                                    <?php if($f->nutritionFact): ?>
                                        <div class="nutrition-content">
                                            <?php echo nl2br(e($f->nutritionFact->formatted_nutrition)); ?>

                                        </div>
                                    <?php else: ?>
                                        <p class="text-muted">Nutrition fact not found</p>
                                    <?php endif; ?>
                                </div></p>
                                    <p><strong>Price:</strong> Rp. <?php echo e(number_format($f->price, 0, ',', '.')); ?>,-</p>

                                    <!-- Customization: Size -->
                                    <div class="mb-3">
                                        <label for="size<?php echo e($f->id); ?>" class="form-label"><strong>Size:</strong></label>
                                        <select class="form-select" id="size<?php echo e($f->id); ?>" name="size" required>
                                            <option value="S">Small (S)</option>
                                            <option value="M" selected>Medium (M)</option>
                                            <option value="L">Large (L) +5000</option>
                                        </select>
                                    </div>
                                
                                
                                <label class="form-label"><strong>Condiments: + 2000 each</strong></label>
                                    <fieldset class="border p-3 mt-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="condiments[]" value="Shoyu" id="condiment-shoyu-<?php echo e($f->id); ?>">
                                            <label class="form-check-label" for="condiment-shoyu-<?php echo e($f->id); ?>">Shoyu</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="condiments[]" value="Wasabi" id="condiment-wasabi-<?php echo e($f->id); ?>">
                                            <label class="form-check-label" for="condiment-wasabi-<?php echo e($f->id); ?>">Wasabi</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="condiments[]" value="Gari" id="condiment-gari-<?php echo e($f->id); ?>">
                                            <label class="form-check-label" for="condiment-gari-<?php echo e($f->id); ?>">Gari</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="condiments[]" value="Togarashi" id="condiment-togarashi-<?php echo e($f->id); ?>">
                                            <label class="form-check-label" for="condiment-togarashi-<?php echo e($f->id); ?>">Togarashi</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="condiments[]" value="Ponzu" id="condiment-ponzu-<?php echo e($f->id); ?>">
                                            <label class="form-check-label" for="condiment-ponzu-<?php echo e($f->id); ?>">Ponzu</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="condiments[]" value="Mayones" id="condiment-mayones-<?php echo e($f->id); ?>">
                                            <label class="form-check-label" for="condiment-mayones-<?php echo e($f->id); ?>">Mayones Jepang</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="condiments[]" value="Teriyaki" id="condiment-teriyaki-<?php echo e($f->id); ?>">
                                            <label class="form-check-label" for="condiment-teriyaki-<?php echo e($f->id); ?>">Teriyaki</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="condiments[]" value="Chili Oil" id="condiment-chilioil-<?php echo e($f->id); ?>">
                                            <label class="form-check-label" for="condiment-chilioil-<?php echo e($f->id); ?>">Chili Oil</label>
                                        </div>
                                    </fieldset>


                                    <div class="mb-3">
                                        <label for="note<?php echo e($f->id); ?>" class="form-label"><strong>Notes
                                                (Optional):</strong></label>
                                        <textarea class="form-control" id="note<?php echo e($f->id); ?>" name="note" rows="2"
                                            placeholder="Ex: No Wasabi, Salt."></textarea>
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-primary">Add to Cart</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WFP-HealthlyFoodOrderingSystem\FoodOrderingSystem\resources\views/customer/menu.blade.php ENDPATH**/ ?>